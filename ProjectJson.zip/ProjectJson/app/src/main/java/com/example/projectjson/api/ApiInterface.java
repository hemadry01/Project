package com.example.projectjson.api;

import com.example.projectjson.model.JsonFile;
import com.example.projectjson.model.SearchResult;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;

public interface ApiInterface {

    @GET("15baeq")
    Call<JsonFile>getResult();
}
