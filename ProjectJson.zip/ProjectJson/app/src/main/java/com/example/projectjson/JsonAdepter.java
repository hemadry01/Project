package com.example.projectjson;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.projectjson.model.SearchResult;

import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

public class JsonAdepter extends RecyclerView.Adapter<JsonAdepter.jsonViewHolder>{
    private List<SearchResult>searchResults;
    private Context mContext;

    public JsonAdepter(List<SearchResult> searchResults, Context mContext) {
        this.searchResults = searchResults;
        this.mContext = mContext;
    }

    @NonNull
    @Override
    public jsonViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.project_layout,parent,false);
        return new jsonViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull jsonViewHolder holder, int position) {

        SearchResult result = searchResults.get(position);
        holder.nameTV.setText(result.getName());
        holder.mobileTV.setText(result.getUser());
        holder.ocupactionTV.setText(result.getWho());
        Glide.with(mContext).load(result.getImage()).into(holder.pictureCI);

    }

    @Override
    public int getItemCount() {
        return searchResults.size();
    }

    public class jsonViewHolder extends RecyclerView.ViewHolder {
        private CircleImageView pictureCI;
        private TextView nameTV,mobileTV,ocupactionTV;
        public jsonViewHolder(@NonNull View itemView) {
            super(itemView);

            pictureCI = itemView.findViewById(R.id.picture_image);
            nameTV = itemView.findViewById(R.id.textView_name);
            mobileTV = itemView.findViewById(R.id.textView_mobile);
            ocupactionTV = itemView.findViewById(R.id.textView_present);
        }
    }
}
